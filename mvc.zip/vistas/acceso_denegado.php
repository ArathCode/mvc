<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../asset/images/logo.jpg" rel="icon" />
    <title>Acceso Denegado</title>
    <link rel="stylesheet" href="../asset/css/denegado.css">
</head>
<body>
    <div class="container">
        <h2>Acceso Denegado</h2>
        <p>No tiene los permisos necesarios para acceder a esta página.</p>
        <img src="asset/images/pgym.jpg" alt="Logo">
        <a href="index.php">Volver al inicio</a>
    </div>
</body>
</html>